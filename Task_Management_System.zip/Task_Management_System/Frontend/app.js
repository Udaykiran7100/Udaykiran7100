document.addEventListener('DOMContentLoaded', () => {
    const taskList = document.getElementById('task-list');

    const fetchTasks = async () => {
        const response = await fetch('http://localhost:5000/tasks');
        const tasks = await response.json();
        taskList.innerHTML = tasks.map(task => `
            <div class="task">
                <h3>${task.title}</h3>
                <p>${task.description}</p>
                <p>Due: ${task.due_date || "No due date"}</p>
                <p>Status: ${task.status}</p>
                <button onclick="deleteTask(${task.id})">Delete</button>
                <button onclick="updateTask(${task.id})">Update</button>
            </div>
        `).join('');
    };

    const deleteTask = async (id) => {
        await fetch(`http://localhost:5000/tasks/${id}`, { method: 'DELETE' });
        fetchTasks();
    };

    document.getElementById('task-form').addEventListener('submit', async (event) => {
        event.preventDefault();
        const title = document.getElementById('title').value;
        const description = document.getElementById('description').value;
        const due_date = document.getElementById('due_date').value;
        await fetch('http://localhost:5000/tasks', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ title, description, due_date, status: 'Pending' }),
        });
        fetchTasks();
    });

    fetchTasks();
});
