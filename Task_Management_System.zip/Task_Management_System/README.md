# Task Management System

A simple web-based task management system with a Flask backend and a minimal frontend.

---

## Features

- Add new tasks with title, description, due date, and status.
- View all tasks in a list.
- Edit or delete tasks.
- Filter tasks by status (Pending or Completed).

---

## Technologies Used

- **Backend**: Flask (Python)
- **Database**: SQLite
- **Frontend**: HTML, CSS, JavaScript

---

## Installation and Setup

### Prerequisites

- Python 3.7 or later
- Node.js (optional, if using additional frontend tools)

### Backend Setup

1. Clone the repository:
   ```bash
   git clone <repository-url>
   cd <repository-folder>

### set up a virtual environment(optional)
python -m venv venv
source venv/bin/activate   # On Windows, use `venv\Scripts\activate`
 
 ### install dependencies:
 pip install -r requirements.txt

### Run the backend:
python app.py
The API will be available at http://localhost:5000.

### Frontend Setup
Open index.html in a browser.
Ensure the backend is running to see the full functionality.

### API Endpoints
Base URL: http://localhost:5000
Get All Tasks: GET /tasks
Create a Task: POST /tasks
 example: payload
 {
  "title": "Task Title",
  "description": "Task Description",
  "due_date": "YYYY-MM-DD",
  "status": "Pending"
}
 Update a Task: PUT /tasks/<id>
 {
  "title": "Updated Title",
  "description": "Updated Description",
  "status": "Completed"
}
Delete a Task: DELETE /tasks/<id>


### project structure
.
├── backend/
│   ├── app.py           # Flask application
│   ├── requirements.txt # Backend dependencies
├── frontend/
│   ├── index.html       # Frontend HTML
│   ├── style.css        # Frontend CSS
│   ├── app.js           # Frontend JavaScript
├── database/
│   ├── database.db      # SQLite database (auto-created)
├── .gitignore
├── README.md

### Future Enhancements
Add user authentication for secure task management.
Implement a mobile-responsive UI.
Add priority levels to tasks.

### License
This project is licensed under the MIT License. See the LICENSE file for more details.

This `README.md` ensures anyone cloning your repository understands the purpose, setup, and functionality of your project.

